"""
Планировщик задач на APScheduler.
Запускает коллекторы по расписанию.
"""
import logging
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from config import config
from db.database import AsyncSessionLocal

logger = logging.getLogger(__name__)


async def _job_opendota() -> None:
    logger.info("[Scheduler] OpenDota sync started")
    from collectors.opendota import run_opendota_sync
    async with AsyncSessionLocal() as db:
        await run_opendota_sync(db)


async def _job_hltv() -> None:
    logger.info("[Scheduler] HLTV sync started")
    from collectors.hltv import run_hltv_sync
    async with AsyncSessionLocal() as db:
        await run_hltv_sync(db)


async def _job_liquipedia() -> None:
    logger.info("[Scheduler] Liquipedia sync started")
    from collectors.liquipedia import run_liquipedia_sync
    async with AsyncSessionLocal() as db:
        await run_liquipedia_sync(db)


async def _job_patches() -> None:
    logger.info("[Scheduler] Patches sync started")
    from collectors.patches import run_patches_sync
    async with AsyncSessionLocal() as db:
        await run_patches_sync(db)


async def _job_telegram() -> None:
    logger.info("[Scheduler] Telegram sync started")
    from collectors.telegram_collector import run_telegram_sync
    async with AsyncSessionLocal() as db:
        await run_telegram_sync(db)


def create_scheduler() -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="UTC")

    # Каждые 2 часа — предстоящие матчи (OpenDota + HLTV)
    scheduler.add_job(
        _job_opendota,
        trigger=IntervalTrigger(hours=config.SCHEDULE_MATCHES_INTERVAL_HOURS),
        id="opendota_sync",
        name="OpenDota sync",
        replace_existing=True,
        misfire_grace_time=300,
    )

    scheduler.add_job(
        _job_hltv,
        trigger=IntervalTrigger(hours=config.SCHEDULE_MATCHES_INTERVAL_HOURS),
        id="hltv_sync",
        name="HLTV sync",
        replace_existing=True,
        misfire_grace_time=300,
    )

    # Каждые 6 часов — статистика команд
    scheduler.add_job(
        _job_liquipedia,
        trigger=IntervalTrigger(hours=config.SCHEDULE_STATS_INTERVAL_HOURS),
        id="liquipedia_sync",
        name="Liquipedia sync",
        replace_existing=True,
        misfire_grace_time=600,
    )

    # Каждые 24 часа — патчи (ночью в 03:00 UTC)
    scheduler.add_job(
        _job_patches,
        trigger=CronTrigger(hour=3, minute=0),
        id="patches_sync",
        name="Patches sync",
        replace_existing=True,
    )

    # Каждые 60 секунд — Telegram-каналы
    scheduler.add_job(
        _job_telegram,
        trigger=IntervalTrigger(seconds=config.SCHEDULE_TG_INTERVAL_SECONDS),
        id="telegram_sync",
        name="Telegram sync",
        replace_existing=True,
        misfire_grace_time=30,
    )

    return scheduler
