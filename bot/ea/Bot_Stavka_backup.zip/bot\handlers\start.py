from aiogram import Router
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from db.models import User
from config import config

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, db: AsyncSession) -> None:
    user_id = message.from_user.id

    # Регистрируем пользователя если нет
    result = await db.execute(select(User).where(User.telegram_id == user_id))
    user = result.scalar_one_or_none()

    if user is None:
        user = User(
            telegram_id=user_id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            is_admin=user_id in config.ADMIN_IDS,
        )
        db.add(user)
        await db.commit()

    name = message.from_user.first_name or "друг"
    await message.answer(
        f"Привет, {name}\\!\n\n"
        "Я бот аналитики ставок CS2 и Dota2\\.\n"
        "Собираю статистику с HLTV, OpenDota, Liquipedia и Telegram\\-каналов\\.\n\n"
        "Только факты и цифры — никаких прогнозов\\.\n\n"
        "Используй /help чтобы увидеть все команды\\."
    )


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    text = (
        "*Доступные команды:*\n\n"
        "*Матчи:*\n"
        "`/upcoming cs2` — матчи CS2 на 48 часов\n"
        "`/upcoming dota2` — матчи Dota2 на 48 часов\n\n"
        "*Аналитика:*\n"
        "`/match NaVi vs Vitality` — отчёт по матчу\n"
        "`/team NaVi` — отчёт по команде \\(CS2\\)\n"
        "`/team NaVi dota2` — отчёт по команде \\(Dota2\\)\n"
        "`/player s1mple` — отчёт по игроку\n\n"
        "*Патчи:*\n"
        "`/patch cs2` — последний патч CS2\n"
        "`/patch dota2` — последний патч Dota2\n"
    )
    await message.answer(text)
