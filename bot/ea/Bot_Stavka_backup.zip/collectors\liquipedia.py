"""
Сборщик данных с Liquipedia (турниры, составы, расписание).
Используем Liquipedia API + HTML парсинг как fallback.
"""
import asyncio
import logging
import random
from datetime import datetime

import aiohttp
from bs4 import BeautifulSoup
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from db.models import Match, Player, Team

logger = logging.getLogger(__name__)

LIQUIPEDIA_API = "https://liquipedia.net"
HEADERS = {
    "User-Agent": "esports-bot/1.0 (contact: your@email.com)",
    "Accept": "application/json",
}
# Liquipedia требует задержку между запросами
REQUEST_DELAY = 30  # секунд (по правилам API)


class LiquipediaCollector:
    def __init__(self, http: aiohttp.ClientSession):
        self.http = http
        self._last_request: float = 0

    async def _throttle(self) -> None:
        """Соблюдаем rate limit Liquipedia."""
        import time
        elapsed = time.time() - self._last_request
        if elapsed < REQUEST_DELAY:
            await asyncio.sleep(REQUEST_DELAY - elapsed)
        self._last_request = time.time()

    async def _get_api(self, game: str, params: dict) -> dict | None:
        await self._throttle()
        url = f"{LIQUIPEDIA_API}/{game}/api.php"
        try:
            async with self.http.get(url, params=params, headers=HEADERS) as resp:
                if resp.status == 200:
                    return await resp.json(content_type=None)
                logger.warning("Liquipedia API %s -> HTTP %s", url, resp.status)
                return None
        except Exception as e:
            logger.error("Liquipedia request error: %s", e)
            return None

    async def _get_html(self, game: str, page: str) -> str | None:
        await self._throttle()
        url = f"{LIQUIPEDIA_API}/{game}/{page}"
        try:
            async with self.http.get(url, headers={**HEADERS, "Accept": "text/html"}) as resp:
                if resp.status == 200:
                    return await resp.text()
                return None
        except Exception as e:
            logger.error("Liquipedia HTML error: %s", e)
            return None

    async def fetch_upcoming_matches(self, game: str) -> list[dict]:
        """
        game: 'dota2' или 'counterstrike'
        """
        params = {
            "action": "parse",
            "page": "Liquipedia:Upcoming_and_ongoing_matches",
            "prop": "wikitext",
            "format": "json",
        }
        data = await self._get_api(game, params)
        if not data:
            return []

        wikitext = data.get("parse", {}).get("wikitext", {}).get("*", "")
        matches = self._parse_wikitext_matches(wikitext, game)
        logger.info("Liquipedia %s: parsed %d matches", game, len(matches))
        return matches

    def _parse_wikitext_matches(self, wikitext: str, game: str) -> list[dict]:
        """Простой парсер wikitext для извлечения матчей."""
        matches = []
        lines = wikitext.split("\n")
        current: dict = {}

        for line in lines:
            line = line.strip()
            if "|team1=" in line:
                current["team1"] = line.split("|team1=")[-1].strip()
            elif "|team2=" in line:
                current["team2"] = line.split("|team2=")[-1].strip()
            elif "|date=" in line:
                date_str = line.split("|date=")[-1].strip()
                try:
                    current["scheduled_at"] = datetime.strptime(date_str[:19], "%Y-%m-%d %H:%M:%S")
                except Exception:
                    current["scheduled_at"] = None
            elif "|tournament=" in line or "|event=" in line:
                key = "tournament=" if "|tournament=" in line else "event="
                current["tournament"] = line.split(f"|{key}")[-1].strip()
            elif "|format=" in line:
                current["match_format"] = line.split("|format=")[-1].strip()
            elif line == "}}" and current.get("team1") and current.get("team2"):
                current["game"] = "dota2" if game == "dota2" else "cs2"
                current["source"] = "liquipedia"
                matches.append(current)
                current = {}

        return matches

    async def fetch_team_roster(self, game: str, team_page: str) -> list[dict]:
        """Получить состав команды по названию страницы."""
        html = await self._get_html(game, team_page)
        if not html:
            return []

        soup = BeautifulSoup(html, "lxml")
        players = []

        for row in soup.select(".roster-card tr"):
            cols = row.select("td")
            if len(cols) < 2:
                continue
            try:
                nickname_el = row.select_one(".ID")
                name_el = row.select_one(".Name")
                country_el = row.select_one(".flag")

                if not nickname_el:
                    continue

                players.append({
                    "nickname": nickname_el.get_text(strip=True),
                    "real_name": name_el.get_text(strip=True) if name_el else None,
                    "country": country_el.get("title") if country_el else None,
                })
            except Exception:
                continue

        return players

    # --- Сохранение в БД ---

    async def save_upcoming_matches(self, db: AsyncSession, game: str) -> int:
        lp_game = "dota2" if game == "dota2" else "counterstrike"
        matches_data = await self.fetch_upcoming_matches(lp_game)
        count = 0

        for m in matches_data:
            if not m.get("team1") or not m.get("team2"):
                continue

            result = await db.execute(
                select(Match).where(
                    Match.team1_name == m["team1"],
                    Match.team2_name == m["team2"],
                    Match.source == "liquipedia",
                    Match.scheduled_at == m.get("scheduled_at"),
                )
            )
            if result.scalar_one_or_none():
                continue

            match = Match(
                source="liquipedia",
                game=game,
                team1_name=m["team1"],
                team2_name=m["team2"],
                tournament=m.get("tournament"),
                match_format=m.get("match_format"),
                scheduled_at=m.get("scheduled_at"),
                status="upcoming",
            )
            db.add(match)
            count += 1

        await db.commit()
        logger.info("Liquipedia %s: saved %d matches", game, count)
        return count


async def run_liquipedia_sync(db: AsyncSession) -> None:
    """Точка входа для планировщика."""
    async with aiohttp.ClientSession() as http:
        collector = LiquipediaCollector(http)
        await collector.save_upcoming_matches(db, "dota2")
        await collector.save_upcoming_matches(db, "cs2")
        logger.info("Liquipedia sync complete")
