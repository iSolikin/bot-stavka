from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from analyzer.analyzer import Analyzer
from cache.redis_cache import cache
from bot.formatters.telegram_format import escape_md, split_message

router = Router()

GAME_ALIASES = {
    "cs": "cs2", "cs2": "cs2",
    "dota": "dota2", "dota2": "dota2", "d2": "dota2",
}


def _parse_team_and_game(query: str) -> tuple[str, str]:
    """Разобрать 'NaVi dota2' -> ('NaVi', 'dota2')."""
    parts = query.rsplit(maxsplit=1)
    if len(parts) == 2 and parts[1].lower() in GAME_ALIASES:
        return parts[0].strip(), GAME_ALIASES[parts[1].lower()]
    return query.strip(), "cs2"


@router.message(Command("team"))
async def cmd_team(message: Message, db: AsyncSession) -> None:
    """
    /team NaVi
    /team NaVi dota2
    """
    args = (message.text or "").split(maxsplit=1)
    if len(args) < 2:
        await message.answer("Использование: `/team Название \\[игра\\]`")
        return

    team_name, game = _parse_team_and_game(args[1])

    # Кэш
    cached = await cache.get_team_report(team_name, game)
    if cached:
        for part in split_message(cached):
            await message.answer(escape_md(part))
        return

    analyzer = Analyzer(db)
    report = await analyzer.team_report(team_name, game)

    await cache.set_team_report(team_name, game, report)

    for part in split_message(report):
        await message.answer(escape_md(part))


@router.message(Command("patch"))
async def cmd_patch(message: Message, db: AsyncSession) -> None:
    """
    /patch cs2
    /patch dota2
    """
    args = (message.text or "").split(maxsplit=1)
    game_raw = args[1].strip().lower() if len(args) > 1 else "cs2"
    game = GAME_ALIASES.get(game_raw, "cs2")

    cached = await cache.get_patch(game)
    if cached:
        await message.answer(escape_md(cached))
        return

    analyzer = Analyzer(db)
    report = await analyzer.patch_report(game)

    await cache.set_patch(game, report)
    await message.answer(escape_md(report))
