import logging
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from config import config
from db.models import Base

logger = logging.getLogger(__name__)

# Движок SQLAlchemy (async)
engine = create_async_engine(
    config.DATABASE_URL,
    echo=config.DEBUG,
    poolclass=NullPool,   # NullPool удобен для async — не держит соединения
)

# Фабрика сессий
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def init_db() -> None:
    """Создаёт все таблицы если их нет. Вызывать при старте приложения."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database initialized")


async def close_db() -> None:
    """Закрывает пул соединений. Вызывать при остановке приложения."""
    await engine.dispose()
    logger.info("Database connection closed")


async def get_session() -> AsyncSession:
    """
    Dependency / контекстный менеджер для получения сессии.

    Использование:
        async with get_session() as session:
            result = await session.execute(...)
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
