"""
Анализатор: принимает запрос, собирает данные через Aggregator,
формирует структурированный текстовый отчёт.
Никаких прогнозов — только факты и цифры.
"""
import logging
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from aggregator.aggregator import Aggregator, MatchReport, TeamReport

logger = logging.getLogger(__name__)


class Analyzer:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.aggregator = Aggregator(db)

    async def team_report(self, team_name: str, game: str) -> str:
        """Текстовый отчёт по команде."""
        report = await self.aggregator.get_team_report(team_name, game)
        if not report:
            return f"Команда «{team_name}» не найдена в базе данных."

        return self._format_team_report(report)

    async def match_report(self, team1: str, team2: str, game: str) -> str:
        """Текстовый отчёт по матчу."""
        report = await self.aggregator.get_match_report(team1, team2, game)
        return self._format_match_report(report)

    async def upcoming_matches(self, game: str, hours: int = 48) -> str:
        """Список предстоящих матчей."""
        matches = await self.aggregator.get_upcoming_matches(game, hours)
        if not matches:
            return f"Предстоящих матчей {game.upper()} на ближайшие {hours} часов не найдено."

        return self._format_upcoming(matches, game, hours)

    async def patch_report(self, game: str) -> str:
        """Отчёт по последнему патчу."""
        patch = await self.aggregator._get_last_patch(game)
        if not patch:
            return f"Информация о патчах {game.upper()} отсутствует."

        lines = [
            f"🔧 Последний патч {game.upper()}",
            f"Версия: {patch['version']}",
        ]
        if patch.get("released_at"):
            lines.append(f"Дата: {patch['released_at'].strftime('%d.%m.%Y')}")
        if patch.get("summary"):
            lines.append(f"Описание: {patch['summary']}")
        if patch.get("url"):
            lines.append(f"Ссылка: {patch['url']}")

        return "\n".join(lines)

    # --- Форматирование ---

    def _format_team_report(self, r: TeamReport) -> str:
        game_label = r.game.upper()
        lines = [
            f"🏆 {r.name} [{game_label}]",
            f"Источники: {', '.join(r.sources)}",
            "",
        ]

        # Рейтинг и статистика
        if r.rating is not None:
            lines.append(f"Рейтинг: {r.rating:.0f}")
        if r.wins or r.losses:
            total = r.wins + r.losses
            winrate = (r.wins / total * 100) if total else 0
            lines.append(f"Побед/Поражений: {r.wins}/{r.losses} (WR: {winrate:.1f}%)")
        if r.form:
            lines.append(f"Форма (посл. 5): {r.form}")

        # Состав
        if r.players:
            lines.append("")
            lines.append("👥 Состав:")
            for p in r.players:
                player_line = f"  • {p['nickname']}"
                if p.get("real_name"):
                    player_line += f" ({p['real_name']})"
                if p.get("country"):
                    player_line += f" [{p['country']}]"
                if p.get("rating"):
                    player_line += f" — рейтинг {p['rating']:.2f}"
                lines.append(player_line)

        # Последние матчи
        if r.recent_matches:
            lines.append("")
            lines.append("📊 Последние матчи:")
            for m in r.recent_matches[:5]:
                date_str = m["date"].strftime("%d.%m") if m.get("date") else "—"
                tournament = m.get("tournament") or "—"
                lines.append(f"  {date_str} | {m['team1']} {m['score']} {m['team2']} | {tournament}")

        # H2H топ-соперники
        if r.head_to_head:
            lines.append("")
            lines.append("⚔️ Head-to-Head:")
            sorted_h2h = sorted(
                r.head_to_head.items(),
                key=lambda x: x[1]["wins"] + x[1]["losses"],
                reverse=True,
            )[:5]
            for _, data in sorted_h2h:
                lines.append(f"  vs {data['opponent']}: {data['wins']}W / {data['losses']}L")

        # Последний патч
        if r.last_patch:
            lines.append("")
            patch = r.last_patch
            date_str = patch["released_at"].strftime("%d.%m.%Y") if patch.get("released_at") else "—"
            lines.append(f"🔧 Актуальный патч: {patch['version']} от {date_str}")

        # Telegram-упоминания
        if r.telegram_mentions:
            lines.append("")
            lines.append("📢 Последние упоминания в Telegram:")
            for msg in r.telegram_mentions[:3]:
                date_str = msg["posted_at"].strftime("%d.%m %H:%M") if msg.get("posted_at") else "—"
                text_preview = msg["text"][:100].replace("\n", " ")
                lines.append(f"  [{date_str}] @{msg['channel']}: {text_preview}...")

        return "\n".join(lines)

    def _format_match_report(self, r: MatchReport) -> str:
        game_label = r.game.upper()
        lines = [
            f"⚔️ {r.team1} vs {r.team2} [{game_label}]",
        ]

        if r.tournament:
            lines.append(f"Турнир: {r.tournament}")
        if r.match_format:
            lines.append(f"Формат: {r.match_format}")
        if r.scheduled_at:
            lines.append(f"Время: {r.scheduled_at.strftime('%d.%m.%Y %H:%M')} UTC")

        # Статистика команд
        for label, stats in [("🔵 " + r.team1, r.team1_stats), ("🔴 " + r.team2, r.team2_stats)]:
            lines.append("")
            lines.append(label)
            if stats:
                if stats.rating is not None:
                    lines.append(f"  Рейтинг: {stats.rating:.0f}")
                if stats.wins or stats.losses:
                    total = stats.wins + stats.losses
                    wr = (stats.wins / total * 100) if total else 0
                    lines.append(f"  W/L: {stats.wins}/{stats.losses} ({wr:.1f}%)")
                if stats.form:
                    lines.append(f"  Форма: {stats.form}")
                if stats.players:
                    nicknames = ", ".join(p["nickname"] for p in stats.players[:5])
                    lines.append(f"  Состав: {nicknames}")
            else:
                lines.append("  Данные отсутствуют")

        # H2H между командами
        if r.head_to_head:
            lines.append("")
            lines.append("📊 История встреч:")
            for m in r.head_to_head[:5]:
                date_str = m["date"].strftime("%d.%m.%Y") if m.get("date") else "—"
                tournament = m.get("tournament") or "—"
                lines.append(f"  {date_str} | {m['team1']} {m['score']} {m['team2']} | {tournament}")

        # Патч
        if r.last_patch:
            lines.append("")
            patch = r.last_patch
            date_str = patch["released_at"].strftime("%d.%m.%Y") if patch.get("released_at") else "—"
            lines.append(f"🔧 Актуальный патч: {patch['version']} от {date_str}")

        return "\n".join(lines)

    def _format_upcoming(self, matches: list[dict], game: str, hours: int) -> str:
        game_label = game.upper()
        lines = [f"📅 Предстоящие матчи {game_label} (ближайшие {hours}ч):"]

        current_tournament = None
        for m in matches:
            tournament = m.get("tournament") or "Без турнира"
            if tournament != current_tournament:
                lines.append(f"\n🏆 {tournament}")
                current_tournament = tournament

            time_str = m["scheduled_at"].strftime("%d.%m %H:%M") if m.get("scheduled_at") else "—"
            fmt = m.get("match_format") or ""
            fmt_str = f" [{fmt}]" if fmt else ""
            lines.append(f"  {time_str} UTC | {m['team1']} vs {m['team2']}{fmt_str}")

        return "\n".join(lines)
