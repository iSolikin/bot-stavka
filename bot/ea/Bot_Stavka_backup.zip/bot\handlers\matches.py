import re
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from analyzer.analyzer import Analyzer
from cache.redis_cache import cache
from bot.formatters.telegram_format import escape_md, split_message

router = Router()

GAME_ALIASES = {
    "cs": "cs2", "cs2": "cs2", "counter-strike": "cs2",
    "dota": "dota2", "dota2": "dota2", "d2": "dota2",
}


def _parse_game(text: str) -> str:
    """Определить игру из текста команды."""
    text_lower = text.lower()
    for alias, game in GAME_ALIASES.items():
        if alias in text_lower:
            return game
    return "cs2"  # по умолчанию


@router.message(Command("upcoming"))
async def cmd_upcoming(message: Message, db: AsyncSession) -> None:
    args = (message.text or "").split(maxsplit=1)
    game = _parse_game(args[1] if len(args) > 1 else "cs2")

    # Проверяем кэш
    cached = await cache.get_upcoming(game)
    if cached:
        for part in split_message(cached):
            await message.answer(escape_md(part))
        return

    analyzer = Analyzer(db)
    report = await analyzer.upcoming_matches(game)

    await cache.set_upcoming(game, report)

    for part in split_message(report):
        await message.answer(escape_md(part))


@router.message(Command("match"))
async def cmd_match(message: Message, db: AsyncSession) -> None:
    """
    /match NaVi vs Vitality
    /match NaVi vs Vitality dota2
    """
    args = (message.text or "").split(maxsplit=1)
    if len(args) < 2:
        await message.answer("Использование: `/match Команда1 vs Команда2 \\[игра\\]`")
        return

    query = args[1].strip()

    # Определяем игру
    game = "cs2"
    for alias, g in GAME_ALIASES.items():
        if query.lower().endswith(alias):
            game = g
            query = query[: -len(alias)].strip()
            break

    # Парсим команды
    vs_match = re.split(r"\s+vs\.?\s+", query, flags=re.IGNORECASE)
    if len(vs_match) < 2:
        await message.answer("Не могу распознать команды\\. Формат: `NaVi vs Vitality`")
        return

    team1 = vs_match[0].strip()
    team2 = vs_match[1].strip()

    # Кэш
    cached = await cache.get_match_report(team1, team2, game)
    if cached:
        for part in split_message(cached):
            await message.answer(escape_md(part))
        return

    analyzer = Analyzer(db)
    report = await analyzer.match_report(team1, team2, game)

    await cache.set_match_report(team1, team2, game, report)

    for part in split_message(report):
        await message.answer(escape_md(part))
